package ro.speedo;

import net.minecraftforge.common.ForgeConfigSpec;

public final class SpeedoConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue ENABLED;
    public static final ForgeConfigSpec.DoubleValue SCALE;
    public static final ForgeConfigSpec.IntValue MARGIN;
    public static final ForgeConfigSpec.IntValue MAX_SPEED;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        ENABLED = b.comment("Afișează vitezometrul").define("enabled", true);
        SCALE = b.comment("Mărimea HUD-ului").defineInRange("scale", 1.0, 0.5, 3.0);
        MARGIN = b.comment("Distanța față de marginea ecranului (px)").defineInRange("margin", 6, 0, 200);
        MAX_SPEED = b.comment("Viteza de la capătul cadranului (km/h). Se mărește automat dacă o depășești.")
                .defineInRange("maxSpeedKmh", 160, 40, 1000);
        SPEC = b.build();
    }
    private SpeedoConfig() {}
}
