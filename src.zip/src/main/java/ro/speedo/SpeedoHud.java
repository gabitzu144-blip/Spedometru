package ro.speedo;

import com.mojang.logging.LogUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;
import net.minecraftforge.fml.ModList;
import org.slf4j.Logger;
import ro.speedo.adapter.CrayfishAdapter;
import ro.speedo.adapter.MtsAdapter;
import ro.speedo.adapter.VehicleAdapter;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/** Vitezometru în stil „pixel": cadran principal + indicator de combustibil. */
public final class SpeedoHud implements IGuiOverlay {
    private static final Logger LOGGER = LogUtils.getLogger();

    // Paletă
    private static final int CYAN = 0xFF18E0FF, RED = 0xFFFF2640, RED_DIM = 0xFF5A1F2A;
    private static final int DIM = 0xFF3A3F47, TICK = 0xFFD9D9D9, YELLOW = 0xFFFFC21A, TEXT_DIM = 0xFF7FB6C2;

    private static final float SWEEP_START = 135f, SWEEP = 270f; // grade, în coordonate de ecran (y în jos)
    private static final float RED_FROM = 0.85f;

    private List<VehicleAdapter> adapters;
    private float shownSpeed;

    private List<VehicleAdapter> adapters() {
        if (adapters == null) {
            adapters = new ArrayList<>();
            try {
                if (ModList.get().isLoaded("vehicle")) adapters.add(new CrayfishAdapter());
            } catch (ReflectiveOperationException | LinkageError e) {
                LOGGER.warn("Vehicle Speedo: nu pot lega MrCrayfish's Vehicle ({})", e.toString());
            }
            try {
                if (ModList.get().isLoaded("mts")) adapters.add(new MtsAdapter());
            } catch (ReflectiveOperationException | LinkageError e) {
                LOGGER.warn("Vehicle Speedo: nu pot lega Immersive Vehicles ({})", e.toString());
            }
        }
        return adapters;
    }

    private Optional<SpeedoData> find(Entity ridden) {
        for (VehicleAdapter a : adapters()) {
            Optional<SpeedoData> d = a.read(ridden);
            if (d.isPresent()) return d;
        }
        return Optional.empty();
    }

    @Override
    public void render(ForgeGui gui, GuiGraphics g, float partialTick, int sw, int sh) {
        Minecraft mc = Minecraft.getInstance();
        if (!SpeedoConfig.ENABLED.get() || mc.player == null || mc.options.hideGui) return;
        Entity ridden = mc.player.getVehicle();
        if (ridden == null) { shownSpeed = 0; return; }
        Optional<SpeedoData> opt = find(ridden);
        if (opt.isEmpty()) { shownSpeed = 0; return; }
        SpeedoData d = opt.get();

        shownSpeed += (d.speedKmh() - shownSpeed) * 0.3f;
        if (Math.abs(d.speedKmh() - shownSpeed) < 0.05f) shownSpeed = d.speedKmh();

        float scale = SpeedoConfig.SCALE.get().floatValue();
        int margin = SpeedoConfig.MARGIN.get();
        final int boxW = 200, boxH = 128;
        float ox = sw - margin - boxW * scale, oy = sh - margin - boxH * scale;

        g.pose().pushPose();
        g.pose().translate(ox, oy, 0);
        g.pose().scale(scale, scale, 1f);

        int maxSpeed = Math.max(SpeedoConfig.MAX_SPEED.get(), (int) Math.ceil(shownSpeed / 20f) * 20);
        drawSpeedGauge(g, mc.font, 130, 66, 56, shownSpeed, maxSpeed, d.gear());
        if (d.hasFuel()) drawFuelGauge(g, mc.font, 32, 92, 24, d);

        g.pose().popPose();
    }

    // ---------------------------------------------------------------- cadran viteză
    private void drawSpeedGauge(GuiGraphics g, Font font, int cx, int cy, int r, float speed, int max, String gear) {
        float frac = Math.min(1f, speed / max);
        // două inele de segmente
        for (int ring = 0; ring < 2; ring++) {
            int rr = r - ring * 4, n = 72 - ring * 6;
            for (int i = 0; i < n; i++) {
                float t = i / (float) (n - 1);
                boolean red = t >= RED_FROM;
                int col = t <= frac ? (red ? RED : CYAN) : (red ? RED_DIM : DIM);
                dot(g, cx, cy, rr, t, 3, col);
            }
        }
        // gradații mari (9) + etichetă la fiecare a doua
        for (int i = 0; i <= 8; i++) {
            float t = i / 8f;
            dot(g, cx, cy, r + 8, t, 5, t >= RED_FROM ? RED : TICK);
        }
        // viteză digitală
        String s = Integer.toString(Math.round(speed));
        drawCentered(g, font, s, cx, cy - 14, 3f, 0xFFFFFFFF);
        drawCentered(g, font, "KM/H", cx, cy + 14, 1f, TEXT_DIM);
        // treapta
        g.fill(cx - 14, cy + 26, cx + 14, cy + 38, 0xFF2A7F8F);
        g.fill(cx - 13, cy + 27, cx + 13, cy + 37, 0xFF0B1E24);
        drawCentered(g, font, gear, cx, cy + 28, 1f, 0xFFFFFFFF);
    }

    // ---------------------------------------------------------------- combustibil
    private void drawFuelGauge(GuiGraphics g, Font font, int cx, int cy, int r, SpeedoData d) {
        float frac = d.fuelFraction();
        int fill = frac <= 0.15f ? RED : YELLOW;
        int n = 40;
        for (int i = 0; i < n; i++) {
            float t = i / (float) (n - 1);
            dot(g, cx, cy, r, t, 3, t <= frac ? fill : DIM);
        }
        for (int i = 0; i <= 4; i++) dot(g, cx, cy, r + 6, i / 4f, 3, i == 0 ? RED : TICK);
        drawCentered(g, font, "FUEL", cx, cy - 15, 0.8f, TEXT_DIM);
        drawCentered(g, font, Math.round(frac * 100) + "%", cx, cy - 5, 1.6f, fill);
        drawCentered(g, font, Math.round(d.fuel()) + "/" + Math.round(d.fuelMax()) + "L", cx, cy + 14, 0.6f, TEXT_DIM);
    }

    // ---------------------------------------------------------------- utilitare
    private static void dot(GuiGraphics g, int cx, int cy, int r, float t, int size, int color) {
        double a = Math.toRadians(SWEEP_START + SWEEP * t);
        int x = cx + (int) Math.round(r * Math.cos(a)), y = cy + (int) Math.round(r * Math.sin(a));
        int h = size / 2;
        g.fill(x - h, y - h, x - h + size, y - h + size, color);
    }

    private static void drawCentered(GuiGraphics g, Font font, String s, int cx, int y, float scale, int color) {
        g.pose().pushPose();
        g.pose().translate(cx, y, 0);
        g.pose().scale(scale, scale, 1f);
        g.drawString(font, s, -font.width(s) / 2, 0, color, true);
        g.pose().popPose();
    }
}
