package ro.speedo;

/** Date afișate de HUD, independente de modul sursă. */
public record SpeedoData(
        float speedKmh,      // viteza în km/h (>= 0)
        String gear,         // "N", "D", "R", "1".."9"
        boolean hasFuel,     // false => ascunde indicatorul de combustibil
        float fuel,          // cantitatea curentă
        float fuelMax) {     // capacitatea
    public float fuelFraction() {
        return fuelMax <= 0 ? 0 : Math.max(0, Math.min(1, fuel / fuelMax));
    }
}
