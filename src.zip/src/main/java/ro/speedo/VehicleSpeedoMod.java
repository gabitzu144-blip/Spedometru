package ro.speedo;

import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;

@Mod(VehicleSpeedoMod.MODID)
public class VehicleSpeedoMod {
    public static final String MODID = "vehiclespeedo";

    public VehicleSpeedoMod() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, SpeedoConfig.SPEC);
    }
}
