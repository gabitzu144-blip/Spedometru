package ro.speedo.adapter;

import net.minecraft.world.entity.Entity;
import ro.speedo.SpeedoData;

import java.lang.reflect.Method;
import java.util.Optional;

/** MrCrayfish's Vehicle Mod: com.mrcrayfish.vehicle.entity.PoweredVehicleEntity */
public final class CrayfishAdapter implements VehicleAdapter {
    private final Class<?> powered;
    private final Method kmh, requiresFuel, curFuel, maxFuel, accel;

    public CrayfishAdapter() throws ReflectiveOperationException {
        powered = Class.forName("com.mrcrayfish.vehicle.entity.PoweredVehicleEntity");
        kmh = powered.getMethod("getKilometersPreHour");
        requiresFuel = powered.getMethod("requiresFuel");
        curFuel = powered.getMethod("getCurrentFuel");
        maxFuel = powered.getMethod("getFuelCapacity");
        accel = powered.getMethod("getAcceleration");
    }

    @Override
    public Optional<SpeedoData> read(Entity e) {
        if (!powered.isInstance(e)) return Optional.empty();
        try {
            float speed = (float) Math.abs(((Number) kmh.invoke(e)).doubleValue());
            boolean fuelOn = (Boolean) requiresFuel.invoke(e);
            float fuel = ((Number) curFuel.invoke(e)).floatValue();
            float cap = ((Number) maxFuel.invoke(e)).floatValue();
            String dir = String.valueOf(accel.invoke(e)); // FORWARD / REVERSE / NONE / CHARGING
            String gear = dir.equals("REVERSE") ? "R" : (speed > 0.5f || dir.equals("FORWARD")) ? "D" : "N";
            return Optional.of(new SpeedoData(speed, gear, fuelOn && cap > 0, fuel, cap));
        } catch (ReflectiveOperationException | RuntimeException ex) {
            return Optional.empty();
        }
    }
}
