package ro.speedo.adapter;

import net.minecraft.world.entity.Entity;
import ro.speedo.SpeedoData;

import java.util.Optional;

public interface VehicleAdapter {
    /** @param ridden entitatea pe care stă jucătorul (player.getVehicle()), nenulă. */
    Optional<SpeedoData> read(Entity ridden);
}
