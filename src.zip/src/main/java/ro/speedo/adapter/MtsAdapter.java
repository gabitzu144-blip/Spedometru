package ro.speedo.adapter;

import net.minecraft.world.entity.Entity;
import ro.speedo.SpeedoData;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Optional;

/**
 * Immersive Vehicles (MTS). Jucătorul stă pe un BuilderEntityLinkedSeat; câmpul public `entity`
 * este PartSeat-ul, iar PartSeat.vehicleOn este vehiculul (EntityVehicleF_Physics).
 */
public final class MtsAdapter implements VehicleAdapter {
    private final Class<?> seatBuilder, vehicleCls, partCls;
    private final Field seatEntity, vehicleOn, velocity, enginesRunning, engines, fuelTank, gearVar;
    private final Method fluidLevel, maxLevel, varValue;

    public MtsAdapter() throws ReflectiveOperationException {
        seatBuilder = Class.forName("mcinterface1201.BuilderEntityLinkedSeat");
        vehicleCls = Class.forName("minecrafttransportsimulator.entities.instances.EntityVehicleF_Physics");
        partCls = Class.forName("minecrafttransportsimulator.entities.instances.APart");
        Class<?> moving = Class.forName("minecrafttransportsimulator.entities.components.AEntityB_Existing");
        Class<?> powered = Class.forName("minecrafttransportsimulator.entities.instances.AEntityVehicleE_Powered");
        Class<?> engine = Class.forName("minecrafttransportsimulator.entities.instances.PartEngine");
        Class<?> tank = Class.forName("minecrafttransportsimulator.entities.instances.EntityFluidTank");
        Class<?> cv = Class.forName("minecrafttransportsimulator.baseclasses.ComputedVariable");
        seatEntity = seatBuilder.getField("entity");
        vehicleOn = partCls.getField("vehicleOn");
        velocity = moving.getField("velocity");
        enginesRunning = powered.getField("enginesRunning");
        engines = powered.getField("engines");
        fuelTank = powered.getField("fuelTank");
        gearVar = engine.getField("currentGearVar");
        fluidLevel = tank.getMethod("getFluidLevel");
        maxLevel = tank.getMethod("getMaxLevel");
        varValue = cv.getMethod("getValue");
    }

    @Override
    public Optional<SpeedoData> read(Entity ridden) {
        try {
            if (!seatBuilder.isInstance(ridden)) return Optional.empty();
            Object seat = seatEntity.get(ridden);
            Object veh = seat == null ? null
                    : vehicleCls.isInstance(seat) ? seat
                    : partCls.isInstance(seat) ? vehicleOn.get(seat) : null;
            if (veh == null) return Optional.empty();

            // MTS: velocity în blocuri/tick -> km/h
            float kmh = (float) Math.abs(velocity.getDouble(veh) * 20.0 * 3.6);

            String gear = "N";
            Object tankObj = fuelTank.get(veh);
            boolean hasFuel = tankObj != null && ((Number) maxLevel.invoke(tankObj)).intValue() > 0;
            float fuel = hasFuel ? ((Number) fluidLevel.invoke(tankObj)).floatValue() : 0;
            float cap = hasFuel ? ((Number) maxLevel.invoke(tankObj)).floatValue() : 0;

            List<?> list = (List<?>) engines.get(veh);
            if (list != null && !list.isEmpty()) {
                Object eng = list.get(0);
                double g = ((Number) varValue.invoke(gearVar.get(eng))).doubleValue();
                gear = g < 0 ? "R" : g == 0 ? "N" : Integer.toString((int) g);
            }
            return Optional.of(new SpeedoData(kmh, gear, hasFuel, fuel, cap));
        } catch (ReflectiveOperationException | RuntimeException ex) {
            return Optional.empty();
        }
    }
}
