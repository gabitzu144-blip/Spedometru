package ro.mooncity;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class RequestTicketsPacket {
    public static void encode(RequestTicketsPacket p, FriendlyByteBuf b) {}
    public static RequestTicketsPacket decode(FriendlyByteBuf b) { return new RequestTicketsPacket(); }

    public static void handle(RequestTicketsPacket p, Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer sp = ctx.get().getSender();
        ctx.get().enqueueWork(() -> {
            if (sp == null || !sp.hasPermissions(2)) return;
            List<TicketListPacket.Entry> out = new ArrayList<>();
            for (var t : TicketManager.LIST) {
                if (t.closed) continue;
                out.add(new TicketListPacket.Entry(t.id, t.player, t.type, t.title, t.desc, t.staff));
                if (out.size() >= 50) break;
            }
            Net.CH.send(net.minecraftforge.network.PacketDistributor.PLAYER.with(() -> sp), new TicketListPacket(out));
        });
        ctx.get().setPacketHandled(true);
    }
}
