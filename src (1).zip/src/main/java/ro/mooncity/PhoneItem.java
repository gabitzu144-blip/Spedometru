package ro.mooncity;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.PacketDistributor;

public class PhoneItem extends Item {
    public PhoneItem(Properties p) { super(p); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level l, Player pl, InteractionHand h) {
        if (!l.isClientSide && pl instanceof ServerPlayer sp) {
            Net.sync(sp);
            Net.CH.send(PacketDistributor.PLAYER.with(() -> sp), new OpenScreenPacket(1, PlayerData.iban(sp)));
        }
        return InteractionResultHolder.sidedSuccess(pl.getItemInHand(h), l.isClientSide);
    }
}
