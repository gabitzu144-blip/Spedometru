package ro.mooncity;

import net.minecraft.nbt.CompoundTag;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

public final class PlayerData {
    private PlayerData() {}

    private static CompoundTag root(Player p) {
        CompoundTag data = p.getPersistentData();
        if (!data.contains(Player.PERSISTED_NBT_TAG)) data.put(Player.PERSISTED_NBT_TAG, new CompoundTag());
        CompoundTag persisted = data.getCompound(Player.PERSISTED_NBT_TAG);
        if (!persisted.contains("mooncity")) persisted.put("mooncity", new CompoundTag());
        return persisted.getCompound("mooncity");
    }

    public static String prefix(Player p) { return root(p).getString("prefix"); }
    public static void setPrefix(Player p, String s) { root(p).putString("prefix", s); }
    public static int id(Player p) { return root(p).getInt("id"); }
    public static void setId(Player p, int id) { root(p).putInt("id", id); }
    public static boolean duty(Player p) { return root(p).getBoolean("duty"); }
    public static void setDuty(Player p, boolean b) { root(p).putBoolean("duty", b); }
    public static int coma(Player p) { return root(p).getInt("coma"); }
    public static void setComa(Player p, int ticks) { root(p).putInt("coma", ticks); }
    public static boolean inComa(Player p) { return coma(p) > 0; }

    public static long cash(Player p) { return root(p).getLong("cash"); }
    public static void setCash(Player p, long v) { root(p).putLong("cash", Math.max(0, v)); }
    public static long bank(Player p) { return root(p).getLong("bank"); }
    public static void setBank(Player p, long v) { root(p).putLong("bank", Math.max(0, v)); }

    public static String iban(Player p) {
        CompoundTag r = root(p);
        if (!r.contains("iban")) {
            long n = Math.abs(p.getUUID().getLeastSignificantBits()) % 1_000_000_000L;
            r.putString("iban", String.format("ROXX-IBAN%09d", n));
        }
        return r.getString("iban");
    }
    public static int jail(Player p) { return root(p).getInt("jail"); }
    public static void setJail(Player p, int ticks) { root(p).putInt("jail", Math.max(0, ticks)); }

    private static CompoundTag garageTag(Player p) {
        CompoundTag r = root(p);
        if (!r.contains("garage")) r.put("garage", new CompoundTag());
        return r.getCompound("garage");
    }
    public static List<String> garageIds(Player p) {
        List<String> l = new ArrayList<>(garageTag(p).getAllKeys());
        Collections.sort(l);
        return l;
    }
    public static boolean hasCar(Player p, String id) { return garageTag(p).contains(id); }
    public static boolean carOut(Player p, String id) { return garageTag(p).getBoolean(id); }
    public static void setCarOut(Player p, String id, boolean b) { garageTag(p).putBoolean(id, b); }
    public static void addCar(Player p, String id) { garageTag(p).putBoolean(id, false); }
    public static void removeCar(Player p, String id) { garageTag(p).remove(id); }

    public static void setJob(Player p, String job, long time) { root(p).putString("jobname", job); root(p).putLong("jobstart", time); }
    public static String jobName(Player p) { return root(p).getString("jobname"); }
    public static long jobStart(Player p) { return root(p).getLong("jobstart"); }
    public static void clearJob(Player p) { root(p).putString("jobname", ""); }

    public static boolean idTaken(ServerPlayer except, int id) {
        for (ServerPlayer o : except.server.getPlayerList().getPlayers())
            if (o != except && id(o) == id) return true;
        return false;
    }
}
