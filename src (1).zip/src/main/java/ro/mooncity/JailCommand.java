package ro.mooncity;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import static net.minecraft.commands.Commands.argument;
import static net.minecraft.commands.Commands.literal;

public class JailCommand {
    public static BlockPos JAIL_POS = null;      // setat cu /jailset
    public static String JAIL_DIM = "minecraft:overworld";

    @SubscribeEvent
    public void register(RegisterCommandsEvent e) {
        e.getDispatcher().register(literal("jailset").requires(s -> s.hasPermission(2)).executes(c -> {
            ServerPlayer p = c.getSource().getPlayerOrException();
            JAIL_POS = p.blockPosition();
            JAIL_DIM = p.level().dimension().location().toString();
            WorldData.saveAll(p.server);
            c.getSource().sendSuccess(() -> Component.literal("Locatia de jail a fost setata."), true);
            return 1;
        }));
        e.getDispatcher().register(literal("jail").requires(s -> s.hasPermission(2))
                .then(argument("jucator", EntityArgument.player())
                        .then(argument("minute", IntegerArgumentType.integer(1, 1440)).executes(c -> {
                            ServerPlayer t = EntityArgument.getPlayer(c, "jucator");
                            if (JAIL_POS == null) { c.getSource().sendFailure(Component.literal("Foloseste mai intai /jailset.")); return 0; }
                            int m = IntegerArgumentType.getInteger(c, "minute");
                            PlayerData.setJail(t, m * 60 * 20);
                            t.teleportTo(t.server.overworld(), JAIL_POS.getX() + .5, JAIL_POS.getY(), JAIL_POS.getZ() + .5, 0, 0);
                            t.sendSystemMessage(Component.literal("Esti in jail " + m + " minute."));
                            return 1;
                        }))));
        e.getDispatcher().register(literal("unjail").requires(s -> s.hasPermission(2))
                .then(argument("jucator", EntityArgument.player()).executes(c -> {
                    ServerPlayer t = EntityArgument.getPlayer(c, "jucator");
                    release(t);
                    return 1;
                })));
    }

    public static void release(ServerPlayer t) {
        PlayerData.setJail(t, 0);
        var w = t.server.overworld();
        BlockPos sp = w.getSharedSpawnPos();
        t.teleportTo(w, sp.getX() + .5, sp.getY(), sp.getZ() + .5, 0, 0);
        t.sendSystemMessage(Component.literal("Ai fost eliberat din jail."));
    }
}
