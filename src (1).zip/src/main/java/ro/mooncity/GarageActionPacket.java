package ro.mooncity;

import net.minecraft.ChatFormatting;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** op: 0 deschide, 1 scoate, 2 parcheaza, 3 vinde, 4 cumpara */
public class GarageActionPacket {
    public final int op; public final String id;
    public GarageActionPacket(int op, String id) { this.op = op; this.id = id; }
    public static void encode(GarageActionPacket p, FriendlyByteBuf b) { b.writeInt(p.op); b.writeUtf(p.id, 40); }
    public static GarageActionPacket decode(FriendlyByteBuf b) { return new GarageActionPacket(b.readInt(), b.readUtf(40)); }

    public static void handle(GarageActionPacket p, Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer sp = ctx.get().getSender();
        ctx.get().enqueueWork(() -> {
            if (sp == null) return;
            if (!Garage.nearBlock(sp)) {
                sp.sendSystemMessage(Component.literal("Nu esti langa un garaj.").withStyle(ChatFormatting.RED));
                return;
            }
            if (!p.id.matches("[a-z0-9_]{0,40}")) return;
            String err = switch (p.op) {
                case 0 -> null;
                case 1 -> Garage.take(sp, p.id);
                case 2 -> Garage.park(sp, p.id);
                case 3 -> Garage.sell(sp, p.id);
                case 4 -> Garage.buy(sp, p.id);
                default -> "Operatie necunoscuta.";
            };
            if (err != null) sp.sendSystemMessage(Component.literal(err).withStyle(ChatFormatting.RED));
            Garage.sendList(sp);
            Net.sync(sp);
        });
        ctx.get().setPacketHandled(true);
    }
}
