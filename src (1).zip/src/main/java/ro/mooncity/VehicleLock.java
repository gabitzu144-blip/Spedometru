package ro.mooncity;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.EntityMountEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.List;

import static net.minecraft.commands.Commands.literal;

public class VehicleLock {
    private static boolean isVehicle(Entity e) {
        ResourceLocation k = ForgeRegistries.ENTITY_TYPES.getKey(e.getType());
        return k != null && (k.getNamespace().equals("mooncityvehicles") || k.getNamespace().equals("vehicle"));
    }

    @SubscribeEvent
    public void mount(EntityMountEvent e) {
        if (!e.isMounting()) return;
        if (!(e.getEntityMounting() instanceof Player p)) return;
        Entity veh = e.getEntityBeingMounted();
        if (!isVehicle(veh)) return;
        String owner = veh.getPersistentData().getString("mc_lock");
        if (owner.isEmpty()) return;
        if (owner.equals(p.getUUID().toString()) || p.hasPermissions(2)) return;
        e.setCanceled(true);
        if (!p.level().isClientSide)
            p.displayClientMessage(Component.literal("Vehiculul e incuiat.").withStyle(ChatFormatting.RED), true);
    }

    @SubscribeEvent
    public void register(RegisterCommandsEvent e) {
        CommandDispatcher<CommandSourceStack> d = e.getDispatcher();
        d.register(literal("vehicle").then(literal("toggle").executes(c -> {
            ServerPlayer p = c.getSource().getPlayerOrException();
            Entity v = p.getVehicle();
            if (v == null || !isVehicle(v)) {
                List<Entity> near = p.level().getEntities(p, p.getBoundingBox().inflate(6), VehicleLock::isVehicle);
                v = null;
                double best = Double.MAX_VALUE;
                for (Entity x : near) { double dd = x.distanceToSqr(p); if (dd < best) { best = dd; v = x; } }
            }
            if (v == null) { p.displayClientMessage(Component.literal("Niciun vehicul in apropiere.").withStyle(ChatFormatting.RED), true); return 0; }
            String owner = v.getPersistentData().getString("mc_lock");
            if (owner.isEmpty()) {
                v.getPersistentData().putString("mc_lock", p.getUUID().toString());
                p.displayClientMessage(Component.literal("Ai incuiat vehiculul.").withStyle(ChatFormatting.GOLD), true);
            } else if (owner.equals(p.getUUID().toString()) || p.hasPermissions(2)) {
                v.getPersistentData().remove("mc_lock");
                p.displayClientMessage(Component.literal("Ai descuiat vehiculul.").withStyle(ChatFormatting.GREEN), true);
            } else {
                p.displayClientMessage(Component.literal("Nu e vehiculul tau.").withStyle(ChatFormatting.RED), true);
                return 0;
            }
            return 1;
        })));
    }
}
