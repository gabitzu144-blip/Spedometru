package ro.mooncity;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

public class WorldData extends SavedData {
    private static final String NAME = "mooncity_world";
    public CompoundTag tag = new CompoundTag();

    public static WorldData get(MinecraftServer s) {
        return s.overworld().getDataStorage().computeIfAbsent(WorldData::load, WorldData::new, NAME);
    }

    public static WorldData load(CompoundTag t) {
        WorldData d = new WorldData();
        d.tag = t.getCompound("d");
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag t) {
        t.put("d", tag);
        return t;
    }

    public static void saveAll(MinecraftServer s) {
        WorldData d = get(s);
        CompoundTag c = new CompoundTag();
        ListTag l = new ListTag();
        for (TicketManager.Ticket t : TicketManager.LIST) {
            CompoundTag x = new CompoundTag();
            x.putInt("id", t.id); x.putUUID("u", t.uuid);
            x.putString("p", t.player); x.putString("ty", t.type); x.putString("ti", t.title);
            x.putString("de", t.desc); x.putString("st", t.staff); x.putBoolean("cl", t.closed);
            l.add(x);
        }
        c.put("tickets", l);
        c.putInt("next", TicketManager.nextId());
        if (JailCommand.JAIL_POS != null) {
            c.putLong("jail", JailCommand.JAIL_POS.asLong());
            c.putString("jdim", JailCommand.JAIL_DIM);
        }
        d.tag = c;
        d.setDirty();
    }

    public static void loadAll(MinecraftServer s) {
        CompoundTag c = get(s).tag;
        TicketManager.LIST.clear();
        for (Tag tg : c.getList("tickets", 10)) {
            CompoundTag x = (CompoundTag) tg;
            TicketManager.Ticket t = new TicketManager.Ticket();
            t.id = x.getInt("id"); t.uuid = x.getUUID("u");
            t.player = x.getString("p"); t.type = x.getString("ty"); t.title = x.getString("ti");
            t.desc = x.getString("de"); t.staff = x.getString("st"); t.closed = x.getBoolean("cl");
            TicketManager.LIST.add(t);
        }
        TicketManager.setNext(Math.max(1, c.getInt("next")));
        if (c.contains("jail")) {
            JailCommand.JAIL_POS = BlockPos.of(c.getLong("jail"));
            JailCommand.JAIL_DIM = c.getString("jdim");
        }
    }
}
