package ro.mooncity;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class TicketManager {
    public static final class Ticket {
        public int id; public UUID uuid; public String player, type, title, desc, staff = "";
        public boolean closed;
    }
    public static final List<Ticket> LIST = new ArrayList<>();
    private static int next = 1;
    private TicketManager() {}

    public static Ticket add(UUID uuid, String player, String type, String title, String desc) {
        Ticket t = new Ticket();
        t.id = next++; t.uuid = uuid; t.player = player; t.type = type; t.title = title; t.desc = desc;
        LIST.add(t);
        return t;
    }
    public static int nextId() { return next; }
    public static void setNext(int n) { next = n; }
    public static Ticket get(int id) {
        for (Ticket t : LIST) if (t.id == id) return t;
        return null;
    }
}
