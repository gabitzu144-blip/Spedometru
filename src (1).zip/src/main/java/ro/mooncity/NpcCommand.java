package ro.mooncity;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.npc.Villager;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.network.PacketDistributor;

import java.util.List;

import static net.minecraft.commands.Commands.argument;
import static net.minecraft.commands.Commands.literal;

public class NpcCommand {
    private static final String[] JOBS = {"none", "constructor", "sudor"};

    @SubscribeEvent
    public void register(RegisterCommandsEvent e) {
        e.getDispatcher().register(literal("npc").requires(s -> s.hasPermission(2))
                .then(literal("create").then(argument("nume", StringArgumentType.word())
                        .executes(c -> create(c, "none"))
                        .then(argument("job", StringArgumentType.word())
                                .suggests((ctx, b) -> SharedSuggestionProvider.suggest(JOBS, b))
                                .executes(c -> create(c, StringArgumentType.getString(c, "job"))))))
                .then(literal("remove").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    Villager v = nearest(p, 5);
                    if (v == null) { c.getSource().sendFailure(Component.literal("Niciun NPC la 5 blocuri.")); return 0; }
                    v.discard();
                    c.getSource().sendSuccess(() -> Component.literal("NPC sters."), true);
                    return 1;
                }))
                .then(literal("list").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    List<Villager> l = p.serverLevel().getEntitiesOfClass(Villager.class, p.getBoundingBox().inflate(64),
                            x -> x.getPersistentData().getBoolean("mc_npc"));
                    for (Villager v : l)
                        c.getSource().sendSuccess(() -> Component.literal(v.getName().getString() + " [" + v.getPersistentData().getString("mc_job") + "] "
                                + v.blockPosition().toShortString()), false);
                    if (l.isEmpty()) c.getSource().sendSuccess(() -> Component.literal("Niciun NPC in apropiere (64 blocuri)."), false);
                    return l.size();
                })));
    }

    private int create(CommandContext<CommandSourceStack> c, String job) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        if (!List.of(JOBS).contains(job)) { c.getSource().sendFailure(Component.literal("Job necunoscut. Alege: none, constructor, sudor.")); return 0; }
        ServerPlayer p = c.getSource().getPlayerOrException();
        ServerLevel lv = p.serverLevel();
        Villager v = EntityType.VILLAGER.create(lv);
        if (v == null) return 0;
        String name = StringArgumentType.getString(c, "nume").replace('_', ' ');
        v.moveTo(p.getX(), p.getY(), p.getZ(), p.getYRot(), 0);
        v.setYHeadRot(p.getYRot());
        v.setNoAi(true);
        v.setInvulnerable(true);
        v.setSilent(true);
        v.setPersistenceRequired();
        v.setCustomName(Component.literal(name));
        v.setCustomNameVisible(true);
        v.getPersistentData().putBoolean("mc_npc", true);
        v.getPersistentData().putString("mc_job", job);
        lv.addFreshEntity(v);
        c.getSource().sendSuccess(() -> Component.literal("NPC creat: " + name + " (job: " + job + ")"), true);
        return 1;
    }

    private static Villager nearest(ServerPlayer p, double r) {
        Villager best = null; double bd = Double.MAX_VALUE;
        for (Villager v : p.serverLevel().getEntitiesOfClass(Villager.class, p.getBoundingBox().inflate(r),
                x -> x.getPersistentData().getBoolean("mc_npc"))) {
            double d = v.distanceToSqr(p);
            if (d < bd) { bd = d; best = v; }
        }
        return best;
    }

    @SubscribeEvent
    public void interact(PlayerInteractEvent.EntityInteract e) {
        if (!(e.getTarget() instanceof Villager v) || !v.getPersistentData().getBoolean("mc_npc")) return;
        e.setCanceled(true);
        e.setCancellationResult(InteractionResult.SUCCESS);
        if (e.getHand() != InteractionHand.MAIN_HAND || e.getLevel().isClientSide) return;
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        String job = v.getPersistentData().getString("mc_job");
        String name = v.getName().getString();
        if (job.equals("none") || job.isEmpty()) {
            sp.sendSystemMessage(Component.literal("<" + name + "> Salut!"));
        } else {
            Net.CH.send(PacketDistributor.PLAYER.with(() -> sp), new JobOpenPacket(job, name));
        }
    }
}
