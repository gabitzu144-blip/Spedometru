package ro.mooncity;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class TicketListPacket {
    public static final class Entry {
        public final int id; public final String player, type, title, desc, staff;
        public Entry(int id, String player, String type, String title, String desc, String staff) {
            this.id = id; this.player = player; this.type = type; this.title = title; this.desc = desc; this.staff = staff;
        }
    }
    public final List<Entry> entries;
    public TicketListPacket(List<Entry> e) { this.entries = e; }

    public static void encode(TicketListPacket p, FriendlyByteBuf b) {
        b.writeInt(p.entries.size());
        for (Entry e : p.entries) {
            b.writeInt(e.id); b.writeUtf(e.player, 64); b.writeUtf(e.type, 32);
            b.writeUtf(e.title, 100); b.writeUtf(e.desc, 600); b.writeUtf(e.staff, 64);
        }
    }
    public static TicketListPacket decode(FriendlyByteBuf b) {
        int n = b.readInt();
        List<Entry> l = new ArrayList<>();
        for (int i = 0; i < n; i++)
            l.add(new Entry(b.readInt(), b.readUtf(64), b.readUtf(32), b.readUtf(100), b.readUtf(600), b.readUtf(64)));
        return new TicketListPacket(l);
    }
    public static void handle(TicketListPacket p, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ro.mooncity.client.ClientData.setTickets(p.entries)));
        ctx.get().setPacketHandled(true);
    }
}
