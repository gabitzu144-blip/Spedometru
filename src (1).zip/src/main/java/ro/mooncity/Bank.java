package ro.mooncity;

import net.minecraft.server.level.ServerPlayer;

public final class Bank {
    private Bank() {}

    /** @return mesaj de eroare sau null daca a reusit */
    public static String deposit(ServerPlayer p, long v) {
        if (v <= 0) return "Suma invalida.";
        if (PlayerData.cash(p) < v) return "Nu ai destul cash.";
        PlayerData.setCash(p, PlayerData.cash(p) - v);
        PlayerData.setBank(p, PlayerData.bank(p) + v);
        Net.sync(p);
        return null;
    }

    public static String withdraw(ServerPlayer p, long v) {
        if (v <= 0) return "Suma invalida.";
        if (PlayerData.bank(p) < v) return "Nu ai destul in banca.";
        PlayerData.setBank(p, PlayerData.bank(p) - v);
        PlayerData.setCash(p, PlayerData.cash(p) + v);
        Net.sync(p);
        return null;
    }

    public static ServerPlayer byIban(ServerPlayer from, String iban) {
        for (ServerPlayer o : from.server.getPlayerList().getPlayers())
            if (PlayerData.iban(o).equalsIgnoreCase(iban.trim())) return o;
        return null;
    }

    public static String transfer(ServerPlayer p, String iban, long v) {
        if (v <= 0) return "Suma invalida.";
        ServerPlayer t = byIban(p, iban);
        if (t == null) return "IBAN inexistent sau jucatorul nu e online.";
        if (t == p) return "Nu poti transfera catre tine.";
        if (PlayerData.bank(p) < v) return "Fonduri insuficiente.";
        PlayerData.setBank(p, PlayerData.bank(p) - v);
        PlayerData.setBank(t, PlayerData.bank(t) + v);
        Net.sync(p); Net.sync(t);
        t.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                "Ai primit $" + v + " de la " + p.getName().getString() + " prin IBAN.")
                .withStyle(net.minecraft.ChatFormatting.GREEN));
        return null;
    }
}
