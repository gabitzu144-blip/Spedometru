package ro.mooncity.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import ro.mooncity.BankPacket;
import ro.mooncity.Net;

public class AtmScreen extends Screen {
    private final String iban;
    private EditBox amount, target;

    public AtmScreen(String iban) { super(Component.literal("ATM")); this.iban = iban; }

    @Override
    protected void init() {
        int x = width / 2 - 130, y = height / 2 - 70;
        amount = new EditBox(font, x, y + 40, 260, 20, Component.literal("Suma"));
        amount.setHint(Component.literal("Suma ($)"));
        amount.setMaxLength(12);
        addRenderableWidget(amount);
        addRenderableWidget(Button.builder(Component.literal("DEPUNERE"), b -> send(0)).bounds(x, y + 66, 128, 20).build());
        addRenderableWidget(Button.builder(Component.literal("RETRAGERE"), b -> send(1)).bounds(x + 132, y + 66, 128, 20).build());
        target = new EditBox(font, x, y + 100, 260, 20, Component.literal("IBAN"));
        target.setHint(Component.literal("IBAN destinatar (ROXX-IBAN#########)"));
        target.setMaxLength(24);
        addRenderableWidget(target);
        addRenderableWidget(Button.builder(Component.literal("TRANSFER"), b -> {
            long v = parse();
            if (v > 0 && !target.getValue().isBlank()) Net.CH.sendToServer(new BankPacket(2, v, target.getValue()));
        }).bounds(x, y + 126, 260, 20).build());
    }

    private long parse() {
        String s = amount.getValue().trim();
        return s.matches("\\d{1,12}") ? Long.parseLong(s) : 0;
    }

    private void send(int op) {
        long v = parse();
        if (v > 0) Net.CH.sendToServer(new BankPacket(op, v, ""));
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        int x = width / 2 - 140, y = height / 2 - 80;
        Panel.draw(g, x, y, 280, 170);
        g.drawString(font, "MOONCITY BANK - ATM", x + 10, y + 8, 0xFFB79CFF, false);
        g.drawString(font, "Cash: $" + String.format("%,d", ClientData.cash) + "   Bank: $" + String.format("%,d", ClientData.bank), x + 10, y + 20, 0xFFFFFFFF, false);
        g.drawString(font, "IBAN-ul tau: " + iban, x + 10, y + 30, 0xFFA99BE0, false);
        super.render(g, mx, my, pt);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
