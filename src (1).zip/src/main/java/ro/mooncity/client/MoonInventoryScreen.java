package ro.mooncity.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.Slot;

/** Inventar restilizat MoonCity (fara rucsac, doar inventarul normal). */
public class MoonInventoryScreen extends InventoryScreen {
    public MoonInventoryScreen(Player p) { super(p); }

    @Override
    protected void renderBg(GuiGraphics g, float pt, int mx, int my) {
        int l = leftPos, t = topPos;
        g.fill(l, t, l + imageWidth, t + imageHeight, 0xF0100A24);
        g.renderOutline(l, t, imageWidth, imageHeight, 0xFF7B5CE6);
        for (Slot s : menu.slots) {
            g.fill(l + s.x - 1, t + s.y - 1, l + s.x + 17, t + s.y + 17, 0xFF1A1236);
            g.renderOutline(l + s.x - 1, t + s.y - 1, 18, 18, 0xFF4A3A8F);
        }
        InventoryScreen.renderEntityInInventoryFollowsMouse(g, l + 51, t + 75, 30,
                (float) (l + 51 - mx), (float) (t + 75 - 50 - my), minecraft.player);
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mx, int my) {
        g.drawString(font, "INVENTAR", 97, 8, 0xFFB79CFF, false);
    }
}
