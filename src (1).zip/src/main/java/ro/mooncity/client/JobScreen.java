package ro.mooncity.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;
import ro.mooncity.JobPacket;
import ro.mooncity.Net;

public class JobScreen extends Screen {
    private final String job, npc;

    public JobScreen(String job, String npc) { super(Component.literal("Job")); this.job = job; this.npc = npc; }

    private String title() { return job.equals("constructor") ? "JOB CONSTRUCTOR" : "JOB SUDOR"; }

    private String text() {
        return job.equals("constructor")
                ? "Salut, meserule! Avem panouri stricate prin oras. Repara 4 componente la timp si primesti $1.500 in banca."
                : "Ai de facut o sudura. Urmareste linia cu cursorul pana la capat fara sa pierzi stabilitatea si primesti $1.200 in banca.";
    }

    @Override
    protected void init() {
        int x = width / 2 - 130, y = height / 2 + 20;
        addRenderableWidget(Button.builder(Component.literal("Da, incep treaba"), b -> {
            Net.CH.sendToServer(new JobPacket(0, job, false));
            minecraft.setScreen(new MinigameScreen(job));
        }).bounds(x, y, 260, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Nu mai vreau"), b -> onClose()).bounds(x, y + 24, 260, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        Panel.draw(g, width / 2 - 140, height / 2 - 70, 280, 130);
        g.drawString(font, title(), width / 2 - 130, height / 2 - 62, 0xFFFFD36B, false);
        g.drawString(font, npc, width / 2 - 130, height / 2 - 50, 0xFFA99BE0, false);
        int yy = height / 2 - 34;
        for (FormattedCharSequence line : font.split(FormattedText.of(text()), 260)) {
            g.drawString(font, line, width / 2 - 130, yy, 0xFFDDDDDD, false);
            yy += 10;
        }
        super.render(g, mx, my, pt);
    }
}
