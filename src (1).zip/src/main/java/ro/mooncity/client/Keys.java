package ro.mooncity.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;
import ro.mooncity.GarageActionPacket;
import ro.mooncity.MoonCity;
import ro.mooncity.Net;

public class Keys {
    public static final KeyMapping MENU = new KeyMapping("key.mooncity.menu", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_K, "key.categories.mooncity");
    public static final KeyMapping GARAGE = new KeyMapping("key.mooncity.garage", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_O, "key.categories.mooncity");
    public static final KeyMapping LOCK = new KeyMapping("key.mooncity.lock", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_L, "key.categories.mooncity");

    @Mod.EventBusSubscriber(modid = MoonCity.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class Register {
        @SubscribeEvent
        public static void keys(RegisterKeyMappingsEvent e) { e.register(MENU); e.register(GARAGE); e.register(LOCK); }
    }

    @Mod.EventBusSubscriber(modid = MoonCity.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
    public static class Tick {
        @SubscribeEvent
        public static void tick(TickEvent.ClientTickEvent e) {
            if (e.phase != TickEvent.Phase.END) return;
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.level == null) return;

            if (mc.player.tickCount % 20 == 0) {
                boolean near = false;
                BlockPos pos = mc.player.blockPosition();
                for (BlockPos b : BlockPos.betweenClosed(pos.offset(-8, -4, -8), pos.offset(8, 4, 8))) {
                    if (mc.level.getBlockState(b).is(MoonCity.GARAGE.get())) { near = true; break; }
                }
                ClientData.nearGarage = near;
            }

            while (MENU.consumeClick()) if (mc.screen == null) mc.setScreen(new MenuScreen());
            while (GARAGE.consumeClick()) if (mc.screen == null) Net.CH.sendToServer(new GarageActionPacket(0, ""));
            while (LOCK.consumeClick()) if (mc.screen == null) Cmd.run("vehicle toggle");
        }
    }
}
