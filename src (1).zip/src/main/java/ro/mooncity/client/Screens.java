package ro.mooncity.client;

import net.minecraft.client.Minecraft;
import ro.mooncity.GarageListPacket;

import java.util.List;

public final class Screens {
    private Screens() {}

    public static void open(int which, String iban) {
        Minecraft mc = Minecraft.getInstance();
        mc.setScreen(which == 0 ? new AtmScreen(iban) : new PhoneScreen(iban));
    }

    public static void openGarage(List<GarageListPacket.Entry> l) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen instanceof GarageScreen gs) gs.update(l);
        else mc.setScreen(new GarageScreen(l));
    }

    public static void openJob(String job, String npc) {
        Minecraft.getInstance().setScreen(new JobScreen(job, npc));
    }
}
