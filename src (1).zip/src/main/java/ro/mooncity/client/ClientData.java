package ro.mooncity.client;

import ro.mooncity.SyncPacket;
import ro.mooncity.TicketListPacket;

import java.util.ArrayList;
import java.util.List;

public final class ClientData {
    public static int id, online, playSeconds;
    public static long cash, bank;
    public static boolean duty, nearGarage;
    public static List<TicketListPacket.Entry> tickets = new ArrayList<>();
    public static int ticketVersion = 0;

    private ClientData() {}

    public static void set(SyncPacket p) {
        id = p.id; cash = p.cash; bank = p.bank; duty = p.duty;
        online = p.online; playSeconds = p.playSeconds;
    }
    public static void setTickets(List<TicketListPacket.Entry> l) { tickets = l; ticketVersion++; }
}
