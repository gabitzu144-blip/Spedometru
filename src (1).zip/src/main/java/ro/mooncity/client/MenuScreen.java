package ro.mooncity.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class MenuScreen extends Screen {
    public MenuScreen() { super(Component.literal("MoonCity")); }

    @Override
    protected void init() {
        int w = 220, x = width / 2 - w / 2, y = height / 2 - 50;
        addRenderableWidget(Button.builder(Component.literal(ClientData.duty ? "OFF DUTY - iesi din serviciu" : "ON DUTY - intri in serviciu"), b -> {
            Cmd.run("duty " + (ClientData.duty ? "off" : "on"));
            onClose();
        }).bounds(x, y, w, 22).build());
        if (minecraft.player != null && minecraft.player.hasPermissions(2)) {
            addRenderableWidget(Button.builder(Component.literal("Admin Panel - staff dashboard"), b -> minecraft.setScreen(new AdminScreen()))
                    .bounds(x, y + 26, w, 22).build());
        }
        addRenderableWidget(Button.builder(Component.literal("Ticket - trimite un ticket"), b -> minecraft.setScreen(new TicketScreen()))
                .bounds(x, y + 52, w, 22).build());
        addRenderableWidget(Button.builder(Component.literal("Interactiuni - interactiuni jucator"), b -> minecraft.setScreen(new InteractScreen()))
                .bounds(x, y + 78, w, 22).build());
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        Panel.draw(g, width / 2 - 120, height / 2 - 80, 240, 190);
        g.drawCenteredString(font, "MOONCITY", width / 2, height / 2 - 70, 0xFFB79CFF);
        super.render(g, mx, my, pt);
    }
}
