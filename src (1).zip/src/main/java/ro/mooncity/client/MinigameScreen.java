package ro.mooncity.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import ro.mooncity.JobPacket;
import ro.mooncity.Net;

import java.util.Random;

/** constructor = bara cu timing (SPACE / click), sudor = urmareste linia cu cursorul. */
public class MinigameScreen extends Screen {
    private static final double WELD_SECONDS = 14.0;
    private final String job;
    private final boolean weld;
    private final Random rnd = new Random();
    private long last = System.nanoTime(), startNs = System.nanoTime();
    private boolean done = false;
    private int closeIn = -1;
    private String msg = "";
    // constructor
    private int round = 0, lives = 3, dir = 1;
    private double pos = 0, zone, zoneW;
    // sudor
    private double stab = 100, phase;

    public MinigameScreen(String job) {
        super(Component.literal("Minijoc"));
        this.job = job;
        this.weld = job.equals("sudor");
        this.phase = rnd.nextDouble() * 6.28;
        newZone();
    }

    private void newZone() {
        zoneW = Math.max(0.10, 0.22 - round * 0.03);
        zone = 0.05 + rnd.nextDouble() * (0.9 - zoneW);
    }

    private double speed() { return 0.7 + round * 0.25; }
    private double f(double u) { return 0.5 + 0.38 * Math.sin(u * Math.PI * 5 + phase); }

    private int x0() { return width / 2 - 190; }
    private int y0() { return height / 2 - 90; }

    private void hit() {
        if (done || weld) return;
        boolean ok = pos >= zone && pos <= zone + zoneW;
        if (ok) {
            round++;
            msg = "Perfect!";
            if (round >= 4) finish(true); else newZone();
        } else {
            lives--;
            msg = "Ai ratat!";
            if (lives <= 0) finish(false);
        }
    }

    private void finish(boolean ok) {
        done = true;
        closeIn = 50;
        msg = ok ? "Reparat! Se calculeaza plata..." : "Ai esuat.";
        Net.CH.sendToServer(new JobPacket(1, job, ok));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        if (!weld) { hit(); return true; }
        return super.mouseClicked(mx, my, btn);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == 32 && !weld) { hit(); return true; }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public void tick() {
        super.tick();
        if (closeIn > 0 && --closeIn == 0) onClose();
    }

    @Override
    public boolean isPauseScreen() { return false; }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        int x0 = x0(), y0 = y0();
        Panel.draw(g, x0, y0, 380, 180);
        double dt = (System.nanoTime() - last) / 1e9;
        last = System.nanoTime();
        if (dt > 0.1) dt = 0.1;

        g.drawString(font, weld ? "COSTURA DE SUDURA" : "REPARATIE PANOU", x0 + 10, y0 + 8, 0xFFFFD36B, false);
        int gx = x0 + 20, gy = y0 + 40, gw = 340;

        if (!weld) {
            if (!done) {
                pos += dir * speed() * dt;
                if (pos > 1) { pos = 1; dir = -1; }
                if (pos < 0) { pos = 0; dir = 1; }
            }
            g.drawString(font, "Componenta " + Math.min(round + 1, 4) + "/4   Vieti: " + lives, x0 + 10, y0 + 22, 0xFFA99BE0, false);
            g.fill(gx, gy + 20, gx + gw, gy + 40, 0xFF1A1236);
            g.renderOutline(gx, gy + 20, gw, 20, 0xFF4A3A8F);
            g.fill(gx + (int) (zone * gw), gy + 20, gx + (int) ((zone + zoneW) * gw), gy + 40, 0xFF2FBF5A);
            int mxp = gx + (int) (pos * gw);
            g.fill(mxp - 1, gy + 14, mxp + 2, gy + 46, 0xFFFFFFFF);
            g.drawString(font, "Apasa SPACE sau click cand bara e in zona verde.", x0 + 10, y0 + 120, 0xFFDDDDDD, false);
        } else {
            int gh = 100;
            double u = Math.min(1.0, (System.nanoTime() - startNs) / 1e9 / WELD_SECONDS);
            int dx = gx + (int) (u * gw), dy = gy + (int) (gh * f(u)) - 20;
            if (!done) {
                double dist = Math.hypot(mx - dx, my - dy);
                if (dist <= 16) stab = Math.min(100, stab + 12 * dt); else stab -= 28 * dt;
                if (stab <= 0) { stab = 0; finish(false); }
                else if (u >= 1.0) finish(true);
            }
            for (int i = 0; i <= 170; i++) {
                double uu = i / 170.0;
                int px = gx + (int) (uu * gw), py = gy + (int) (gh * f(uu)) - 20;
                g.fill(px, py, px + 2, py + 2, uu <= u ? 0xFF7CFF8A : 0xFF6A5FB0);
            }
            g.fill(dx - 3, dy - 3, dx + 4, dy + 4, 0xFFFFD36B);
            g.drawString(font, "Tine cursorul pe punct", x0 + 10, y0 + 22, 0xFFA99BE0, false);
            g.fill(gx, y0 + 140, gx + gw, y0 + 148, 0xFF1A1236);
            g.fill(gx, y0 + 140, gx + (int) (gw * stab / 100.0), y0 + 148, stab > 35 ? 0xFF2FBF5A : 0xFFFF5577);
            g.drawString(font, "Stabilitate", gx, y0 + 150, 0xFFA99BE0, false);
        }
        if (!msg.isEmpty()) g.drawCenteredString(font, msg, width / 2, y0 + 165, 0xFFFFFFFF);
        super.render(g, mx, my, pt);
    }
}
