package ro.mooncity.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;
import ro.mooncity.Net;
import ro.mooncity.RequestTicketsPacket;
import ro.mooncity.TicketListPacket;

import java.util.List;

public class AdminScreen extends Screen {
    // eticheta, descriere, are nevoie de valoare, hint valoare
    private static final String[][] ACTIONS = {
            {"Give Money", "Ofera bani", "1", "Suma"},
            {"Take Money", "Retrage bani", "1", "Suma"},
            {"Ban Player", "Ban cu motiv", "1", "Motiv"},
            {"Revive", "Ridica din coma", "0", ""},
            {"Respawn", "Teleporteaza la spawn", "0", ""},
            {"Stats", "Vezi statistici", "0", ""},
            {"Kick Player", "Scoate de pe server", "1", "Motiv"},
    };
    private int tab = 0, action = -1, selTicket = -1, seenVersion = -1;
    private String name = "", value = "", reply = "";
    private EditBox nameBox, valueBox, replyBox;

    public AdminScreen() { super(Component.literal("Admin Panel")); }

    private int x0() { return width / 2 - 190; }
    private int y0() { return height / 2 - 115; }

    private void save() {
        if (nameBox != null) name = nameBox.getValue();
        if (valueBox != null) value = valueBox.getValue();
        if (replyBox != null) reply = replyBox.getValue();
    }

    private void refresh() { Net.CH.sendToServer(new RequestTicketsPacket()); }

    private TicketListPacket.Entry find(int id) {
        for (var e : ClientData.tickets) if (e.id == id) return e;
        return null;
    }

    @Override
    protected void init() {
        nameBox = valueBox = replyBox = null;
        int x0 = x0(), y0 = y0();
        addRenderableWidget(Button.builder(Component.literal(tab == 0 ? "> ACTIUNI" : "ACTIUNI"), b -> { save(); tab = 0; selTicket = -1; rebuildWidgets(); })
                .bounds(x0 + 8, y0 + 8, 100, 20).build());
        addRenderableWidget(Button.builder(Component.literal(tab == 1 ? "> TICKETE (" + ClientData.tickets.size() + ")" : "TICKETE (" + ClientData.tickets.size() + ")"), b -> {
            save(); tab = 1; refresh(); rebuildWidgets();
        }).bounds(x0 + 112, y0 + 8, 110, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Inchide"), b -> onClose()).bounds(x0 + 316, y0 + 8, 56, 20).build());

        if (tab == 0) initActions(x0, y0); else initTickets(x0, y0);
    }

    private void initActions(int x0, int y0) {
        for (int i = 0; i < ACTIONS.length; i++) {
            int idx = i;
            String label = (i == action ? "> " : "") + ACTIONS[i][0];
            addRenderableWidget(Button.builder(Component.literal(label), b -> { save(); action = idx; rebuildWidgets(); })
                    .bounds(x0 + 8 + (i % 3) * 122, y0 + 38 + (i / 3) * 24, 118, 20).build());
        }
        if (action >= 0) {
            nameBox = new EditBox(font, x0 + 8, y0 + 130, 180, 18, Component.literal("Jucator"));
            nameBox.setHint(Component.literal("Nume jucator"));
            nameBox.setValue(name);
            addRenderableWidget(nameBox);
            if (ACTIONS[action][2].equals("1")) {
                valueBox = new EditBox(font, x0 + 196, y0 + 130, 176, 18, Component.literal("Valoare"));
                valueBox.setMaxLength(100);
                valueBox.setHint(Component.literal(ACTIONS[action][3]));
                valueBox.setValue(value);
                addRenderableWidget(valueBox);
            }
            addRenderableWidget(Button.builder(Component.literal("EXECUTA: " + ACTIONS[action][0]), b -> execute())
                    .bounds(x0 + 8, y0 + 156, 364, 22).build());
        }
    }

    private void execute() {
        save();
        String n = name.trim(), v = value.trim();
        if (n.isEmpty()) return;
        String cmd = switch (action) {
            case 0 -> v.matches("\\d{1,12}") ? "money " + n + " cash add " + v : null;
            case 1 -> v.matches("\\d{1,12}") ? "money " + n + " cash take " + v : null;
            case 2 -> "ban " + n + (v.isEmpty() ? "" : " " + v);
            case 3 -> "revive " + n;
            case 4 -> "respawn " + n;
            case 5 -> "stats " + n;
            case 6 -> "kick " + n + (v.isEmpty() ? "" : " " + v);
            default -> null;
        };
        if (cmd != null) Cmd.run(cmd);
    }

    private void initTickets(int x0, int y0) {
        if (selTicket < 0) {
            List<TicketListPacket.Entry> l = ClientData.tickets;
            for (int i = 0; i < Math.min(7, l.size()); i++) {
                var t = l.get(i);
                String s = "#" + t.id + " [" + t.type + "] " + t.player + " - " + t.title;
                if (s.length() > 55) s = s.substring(0, 55) + "..";
                addRenderableWidget(Button.builder(Component.literal(s), b -> { selTicket = t.id; rebuildWidgets(); })
                        .bounds(x0 + 8, y0 + 38 + i * 24, 364, 20).build());
            }
        } else {
            int id = selTicket;
            addRenderableWidget(Button.builder(Component.literal("< INAPOI"), b -> { selTicket = -1; refresh(); rebuildWidgets(); }).bounds(x0 + 8, y0 + 34, 70, 18).build());
            addRenderableWidget(Button.builder(Component.literal("PREIA"), b -> { Cmd.run("ticket take " + id); refresh(); }).bounds(x0 + 8, y0 + 160, 88, 20).build());
            addRenderableWidget(Button.builder(Component.literal("TP TO PLAYER"), b -> Cmd.run("ticket tp " + id)).bounds(x0 + 100, y0 + 160, 130, 20).build());
            addRenderableWidget(Button.builder(Component.literal("REZOLVA"), b -> { Cmd.run("ticket close " + id); selTicket = -1; refresh(); rebuildWidgets(); }).bounds(x0 + 234, y0 + 160, 138, 20).build());
            replyBox = new EditBox(font, x0 + 8, y0 + 186, 300, 18, Component.literal("Raspuns"));
            replyBox.setMaxLength(200);
            replyBox.setHint(Component.literal("Scrie raspuns..."));
            replyBox.setValue(reply);
            addRenderableWidget(replyBox);
            addRenderableWidget(Button.builder(Component.literal("TRIMITE"), b -> {
                save();
                if (!reply.isBlank()) { Cmd.run("ticket reply " + id + " " + reply.trim()); reply = ""; rebuildWidgets(); }
            }).bounds(x0 + 312, y0 + 186, 60, 18).build());
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (tab == 1 && ClientData.ticketVersion != seenVersion) {
            seenVersion = ClientData.ticketVersion;
            save();
            rebuildWidgets();
        }
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        int x0 = x0(), y0 = y0();
        Panel.draw(g, x0, y0, 380, 215);
        super.render(g, mx, my, pt);
        if (tab == 0 && action >= 0)
            g.drawString(font, ACTIONS[action][1], x0 + 8, y0 + 116, 0xFFB79CFF, false);
        if (tab == 0 && action < 0)
            g.drawString(font, "Alege o actiune.", x0 + 8, y0 + 130, 0xFFA99BE0, false);
        if (tab == 1 && selTicket < 0 && ClientData.tickets.isEmpty())
            g.drawString(font, "Niciun ticket deschis.", x0 + 8, y0 + 44, 0xFFA99BE0, false);
        if (tab == 1 && selTicket >= 0) {
            var t = find(selTicket);
            if (t == null) { selTicket = -1; return; }
            g.drawString(font, "#" + t.id + " [" + t.type + "] " + t.player, x0 + 90, y0 + 38, 0xFFFFD36B, false);
            g.drawString(font, t.title, x0 + 8, y0 + 58, 0xFFFFFFFF, false);
            g.drawString(font, t.staff.isEmpty() ? "Nepreluat" : "Preluat de " + t.staff, x0 + 8, y0 + 70, 0xFF7CFF8A, false);
            int yy = y0 + 86;
            for (FormattedCharSequence line : font.split(FormattedText.of(t.desc), 360)) {
                if (yy > y0 + 150) break;
                g.drawString(font, line, x0 + 8, yy, 0xFFDDDDDD, false);
                yy += 10;
            }
        }
    }
}
