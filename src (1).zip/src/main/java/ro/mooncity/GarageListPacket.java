package ro.mooncity;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class GarageListPacket {
    public static final class Entry {
        public final String id; public final boolean out;
        public Entry(String id, boolean out) { this.id = id; this.out = out; }
    }
    public final List<Entry> entries;
    public GarageListPacket(List<Entry> e) { this.entries = e; }

    public static void encode(GarageListPacket p, FriendlyByteBuf b) {
        b.writeInt(p.entries.size());
        for (Entry e : p.entries) { b.writeUtf(e.id, 40); b.writeBoolean(e.out); }
    }
    public static GarageListPacket decode(FriendlyByteBuf b) {
        int n = b.readInt();
        List<Entry> l = new ArrayList<>();
        for (int i = 0; i < n; i++) l.add(new Entry(b.readUtf(40), b.readBoolean()));
        return new GarageListPacket(l);
    }
    public static void handle(GarageListPacket p, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ro.mooncity.client.Screens.openGarage(p.entries)));
        ctx.get().setPacketHandled(true);
    }
}
