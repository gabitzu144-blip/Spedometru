package ro.mooncity;

import net.minecraft.ChatFormatting;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.Set;
import java.util.function.Supplier;

public class TicketPacket {
    public final String type, title, desc;
    public TicketPacket(String type, String title, String desc) { this.type = type; this.title = title; this.desc = desc; }
    public static void encode(TicketPacket p, FriendlyByteBuf b) { b.writeUtf(p.type, 32); b.writeUtf(p.title, 100); b.writeUtf(p.desc, 600); }
    public static TicketPacket decode(FriendlyByteBuf b) { return new TicketPacket(b.readUtf(32), b.readUtf(100), b.readUtf(600)); }

    public static void handle(TicketPacket p, Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer sp = ctx.get().getSender();
        ctx.get().enqueueWork(() -> {
            if (sp == null) return;
            String type = Set.of("INTREBARE", "RAPORT", "BUG").contains(p.type) ? p.type : "INTREBARE";
            String title = p.title.trim(); if (title.length() > 60) title = title.substring(0, 60);
            String desc = p.desc.trim(); if (desc.length() > 400) desc = desc.substring(0, 400);
            if (title.isEmpty() || desc.isEmpty()) return;
            var t = TicketManager.add(sp.getUUID(), sp.getName().getString(), type, title, desc);
            WorldData.saveAll(sp.server);
            sp.sendSystemMessage(Component.literal("Ticket #" + t.id + " trimis. Un staff te va ajuta.").withStyle(ChatFormatting.GREEN));
            for (ServerPlayer o : sp.server.getPlayerList().getPlayers())
                if (o.hasPermissions(2))
                    o.sendSystemMessage(Component.literal("[Ticket #" + t.id + "] " + t.player + ": " + t.title).withStyle(ChatFormatting.GOLD));
        });
        ctx.get().setPacketHandled(true);
    }
}
