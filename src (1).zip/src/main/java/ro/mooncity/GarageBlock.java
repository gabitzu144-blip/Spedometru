package ro.mooncity;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

public class GarageBlock extends Block {
    public GarageBlock(Properties p) { super(p); }

    @Override
    public InteractionResult use(BlockState s, Level l, BlockPos pos, Player pl, InteractionHand h, BlockHitResult hit) {
        if (!l.isClientSide) pl.displayClientMessage(Component.literal("Apasa [O] pentru a deschide garajul."), true);
        return InteractionResult.sidedSuccess(l.isClientSide);
    }
}
