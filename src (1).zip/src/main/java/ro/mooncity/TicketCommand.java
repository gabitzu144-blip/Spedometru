package ro.mooncity;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import static net.minecraft.commands.Commands.argument;
import static net.minecraft.commands.Commands.literal;

public class TicketCommand {
    @SubscribeEvent
    public void register(RegisterCommandsEvent e) {
        e.getDispatcher().register(literal("ticket").requires(s -> s.hasPermission(2))
                .then(literal("take").then(argument("id", IntegerArgumentType.integer(1)).executes(c -> {
                    var t = TicketManager.get(IntegerArgumentType.getInteger(c, "id"));
                    if (t == null) return fail(c.getSource());
                    t.staff = c.getSource().getTextName();
                    WorldData.saveAll(c.getSource().getServer());
                    msg(c.getSource(), t, "Ticketul #" + t.id + " a fost preluat de " + t.staff + ".");
                    return 1;
                })))
                .then(literal("close").then(argument("id", IntegerArgumentType.integer(1)).executes(c -> {
                    var t = TicketManager.get(IntegerArgumentType.getInteger(c, "id"));
                    if (t == null) return fail(c.getSource());
                    t.closed = true;
                    WorldData.saveAll(c.getSource().getServer());
                    msg(c.getSource(), t, "Ticketul #" + t.id + " a fost rezolvat de " + c.getSource().getTextName() + ".");
                    return 1;
                })))
                .then(literal("tp").then(argument("id", IntegerArgumentType.integer(1)).executes(c -> {
                    var t = TicketManager.get(IntegerArgumentType.getInteger(c, "id"));
                    ServerPlayer staff = c.getSource().getPlayer();
                    if (t == null || staff == null) return fail(c.getSource());
                    ServerPlayer target = c.getSource().getServer().getPlayerList().getPlayer(t.uuid);
                    if (target == null) { c.getSource().sendFailure(Component.literal("Jucatorul nu e online.")); return 0; }
                    staff.teleportTo(target.serverLevel(), target.getX(), target.getY(), target.getZ(), target.getYRot(), target.getXRot());
                    return 1;
                })))
                .then(literal("reply").then(argument("id", IntegerArgumentType.integer(1))
                        .then(argument("text", StringArgumentType.greedyString()).executes(c -> {
                            var t = TicketManager.get(IntegerArgumentType.getInteger(c, "id"));
                            if (t == null) return fail(c.getSource());
                            msg(c.getSource(), t, "[Ticket #" + t.id + "] " + c.getSource().getTextName() + ": " + StringArgumentType.getString(c, "text"));
                            return 1;
                        })))));
    }

    private int fail(CommandSourceStack s) { s.sendFailure(Component.literal("Ticket inexistent.")); return 0; }

    private void msg(CommandSourceStack s, TicketManager.Ticket t, String text) {
        Component m = Component.literal(text).withStyle(ChatFormatting.GOLD);
        s.sendSuccess(() -> m, false);
        ServerPlayer owner = s.getServer().getPlayerList().getPlayer(t.uuid);
        if (owner != null) owner.sendSystemMessage(m);
    }
}
