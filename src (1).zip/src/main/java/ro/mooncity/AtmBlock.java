package ro.mooncity;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.network.PacketDistributor;

public class AtmBlock extends Block {
    public AtmBlock(Properties p) { super(p); }

    @Override
    public InteractionResult use(BlockState s, Level l, BlockPos pos, Player pl, InteractionHand h, BlockHitResult hit) {
        if (!l.isClientSide && pl instanceof ServerPlayer sp) {
            Net.sync(sp);
            Net.CH.send(PacketDistributor.PLAYER.with(() -> sp), new OpenScreenPacket(0, PlayerData.iban(sp)));
        }
        return InteractionResult.sidedSuccess(l.isClientSide);
    }
}
